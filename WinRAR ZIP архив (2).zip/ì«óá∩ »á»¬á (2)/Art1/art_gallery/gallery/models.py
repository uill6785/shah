# models.py
from django.db import models
from django.contrib.auth.models import User

class Category(models.Model):
    name = models.CharField("Категория", max_length=100)

    def __str__(self):
        return self.name

class Artwork(models.Model):
    title       = models.CharField("Название", max_length=255)
    description = models.TextField("Описание")
    image       = models.ImageField("Изображение", upload_to='artworks/')
    category    = models.ForeignKey(Category, verbose_name="Категория", on_delete=models.SET_NULL, null=True, blank=True)
    tags        = models.CharField("Теги", max_length=255, blank=True)
    artist      = models.CharField("Художник", max_length=100, blank=True)
    price       = models.DecimalField("Цена", max_digits=10, decimal_places=2, null=True, blank=True)
    author      = models.ForeignKey(User, verbose_name="Автор", on_delete=models.CASCADE)
    created_at  = models.DateTimeField("Добавлено", auto_now_add=True)
    is_visible  = models.BooleanField("Показывать на сайте", default=True)

    def __str__(self):
        return self.title

class SliderImage(models.Model):
    title     = models.CharField("Название", max_length=255)
    image     = models.ImageField("Изображение", upload_to='slider/')
    is_active = models.BooleanField("Активно", default=True)

    def __str__(self):
        return self.title






