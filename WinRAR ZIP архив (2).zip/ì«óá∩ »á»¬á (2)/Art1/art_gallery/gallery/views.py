from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import ListView, DetailView
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.core.mail import send_mail
from django.db.models import Q

from .models import Artwork, SliderImage
from .forms import ArtworkForm, ContactForm

class HomeView(ListView):
    model = Artwork
    template_name = "gallery/home.html"
    context_object_name = "artworks"
    def get_queryset(self):
        return Artwork.objects.filter(is_visible=True).order_by('-created_at')
    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['slider_images'] = SliderImage.objects.filter(is_active=True)
        return ctx

class ArtworkDetailView(DetailView):
    model = Artwork
    template_name = "gallery/artwork_detail.html"

@login_required
def add_artwork(request):
    form = ArtworkForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        art = form.save(commit=False)
        art.author = request.user
        art.save()
        return redirect('profile')
    return render(request, 'gallery/add_artwork.html', {'form': form})

@login_required
def edit_artwork(request, pk):
    art = get_object_or_404(Artwork, pk=pk, author=request.user)
    form = ArtworkForm(request.POST or None, request.FILES or None, instance=art)
    if form.is_valid():
        form.save()
        return redirect('profile')
    return render(request, 'gallery/edit_artwork.html', {'form': form, 'artwork': art})

@login_required
def delete_artwork(request, pk):
    art = get_object_or_404(Artwork, pk=pk, author=request.user)
    if request.method == 'POST':
        art.delete()
        return redirect('profile')
    return render(request, 'gallery/delete_artwork.html', {'artwork': art})

@login_required
def profile(request):
    artworks = Artwork.objects.filter(author=request.user).order_by('-created_at')
    return render(request, 'gallery/profile.html', {'artworks': artworks})

def contact(request):
    form = ContactForm(request.POST or None)
    if form.is_valid():
        send_mail(
            subject=f"Сообщение от {form.cleaned_data['name']}",
            message=form.cleaned_data['message'],
            from_email=form.cleaned_data['email'],
            recipient_list=['webmaster@localhost'],
        )
        messages.success(request, 'Ваше сообщение успешно отправлено!')
        return redirect('contact')
    return render(request, 'gallery/contact.html', {'form': form})

def register(request):
    form = UserCreationForm(request.POST or None)
    if form.is_valid():
        user = form.save()
        login(request, user)
        return redirect('home')
    return render(request, 'registration/register.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')

def search(request):
    q = request.GET.get('q','')
    results = Artwork.objects.filter(
        Q(title__icontains=q)|Q(description__icontains=q)
    ) if q else Artwork.objects.none()
    return render(request, 'gallery/search_results.html', {'results': results, 'query': q})

@login_required
def toggle_visibility(request, pk):
    art = get_object_or_404(Artwork, pk=pk, author=request.user)
    art.is_visible = not art.is_visible
    art.save()
    return redirect('artwork_detail', pk=pk)


from .forms import ContactForm
from django.core.mail import send_mail
from django.conf import settings

def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            # Обработка формы
            subject = f"Новое сообщение от {form.cleaned_data['name']}"
            message = form.cleaned_data['message']
            email_from = form.cleaned_data['email']
            send_mail(subject, message, email_from, ['your@email.com'])
            return render(request, 'gallery/contact_success.html')
    else:
        form = ContactForm()
    return render(request, 'gallery/contact.html', {'form': form})




