from django.apps import apps
from django.db.models.signals import post_migrate
from django.dispatch import receiver

@receiver(post_migrate)
def create_default_categories(sender, **kwargs):
    # сработает после миграции любой app, но нам нужен только наш
    if sender.name == 'gallery':
        Category = apps.get_model('gallery', 'Category')
        default = ['Живопись', 'Фотография', 'Скульптура', 'Графика', 'Дизайн']
        for name in default:
            Category.objects.get_or_create(name=name)


