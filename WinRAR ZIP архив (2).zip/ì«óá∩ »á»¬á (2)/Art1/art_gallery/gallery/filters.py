from django_filters import FilterSet, CharFilter
from .models import Artwork

class ArtworkFilter(FilterSet):
    title = CharFilter(lookup_expr='icontains', label="Поиск по названию")

    class Meta:
        model = Artwork
        fields = ['category', 'title']