from django.contrib import admin
from .models import SliderImage
from .models import Category
from .models import Artwork
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin

admin.site.unregister(User)
admin.site.register(User, UserAdmin)

admin.site.register(Category)

admin.site.register(SliderImage)
admin.site.register(Artwork)









